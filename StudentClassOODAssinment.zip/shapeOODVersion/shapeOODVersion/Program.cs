﻿using System;
using System.Configuration;
using System.Net.NetworkInformation;
using System.Text.RegularExpressions;
/*
name = "Benjamin Batie";
major = "Computer Information Systems";
startDate = new DateTime(2020, 8, 20);
anticipatedGraduationDate = new DateTime(2023, 12, 9);
state = "South Dakota";
country = "United States of America";
email = "Ben.Batie@trojans.dsu.edu";
phone = "1 (605) 281-9170";
mailingAddress = "402 10th Street / PO Box 522";
*/

//two constructors
//Student Id read only
class Students {
    private int numberOfStudents = 0;
    private int count = 0;
    private int id = 0;
    private string name = "";
    private string major = "";
    private DateTime startDate = DateTime.Now;
    private DateTime anticipatedGraduationDate = DateTime.Now;
    private string state = "";
    private string country = "";
    private string email = "";
    private string mailingAddress = "";

    public Students()
    {

        numberOfStudents++;
        count++;
        id = count;
        name = "Unknown";
        major = "Exploratory Studies - Fine Arts/Humanities";
        startDate = DateTime.Now;
        anticipatedGraduationDate = new DateTime(startDate.Year + 5, startDate.Month - 3, startDate.Day);
        state = "South Dakota";
        country = "United States of America";
        email = "FirstName.LastName@trojans.dsu.edu";
        phone = "1 (234) 567-8910";
        mailingAddress = "Somewhere over the rainbow";

    }

    public int Count
    {
        get { return count; }
        set { count = value; }
    }
    public int ID
    {
        get { return id; }
        set { id = value; }
    }
    public string Name {
        get { return name; }
        set { name = value; }
    }
    public string Major {
        get { return major; }
        set { major = value; }
    }

    public DateTime Startdate {
        get { return startDate; }
        set { startDate = value; }
    }

    public DateTime AGD {
        get { return anticipatedGraduationDate; }
        set { anticipatedGraduationDate = value; }
    }


    public string State {
        get { return state; }
        set { state = value; }
    }


    public string Country
    {
        get { return country; }
        set { country = value; }
    }

    public string Email {
        get { return email; }
             
        set {
            string regex = "%@%";
            Regex myRegexValidator = new Regex(regex);

                email = value; 
        }
    }

    private string phone = "";
    public string Phone {
        get { return phone; }
        set { phone = value; }
    }

    
    public string MA { 
        get { return mailingAddress; }
        set { mailingAddress = value; }
    }
    
    

    public void Student(string NAME, string MAJOR, DateTime START, DateTime END, string STATE, string COUNTRY, string EMAIL, string PHONE, string MAILADDRESS)
    {
        numberOfStudents++;
        count++;
        id = count;
        name = NAME;
        major = MAJOR;
        startDate = START;
        anticipatedGraduationDate = END;
        state = STATE;
        country = COUNTRY;
        email = EMAIL;
        phone = PHONE;
        mailingAddress = MAILADDRESS;
    }
    public void printStudents()
    {
        if (id != 2)
        {
            Console.WriteLine("Id: " + id + "Name: " + name + "Major: " + major
            + " Start Date: " + startDate + " Graduation Date " + anticipatedGraduationDate);
            Console.WriteLine("Address " + mailingAddress + ", " + state + country);
            Console.WriteLine("Email: " + email + " Phone " + phone);

        }
        else {
            Console.WriteLine("RESTRICTED");
        }
    }
    ~Students()
    {
        numberOfStudents--;
    }

    static void Main(string[] args)
    {
        int number = 0;
        Console.WriteLine("How many students do you want to add?");
        number = Convert.ToInt32(Console.ReadLine());
        Students[] studentsFromClass = new Students[number];
        for (int i = 0; i < number; i++) {
            studentsFromClass[i] = new Students();
        }
             
        for (int i = 0; i < number; i++)
        {
            //studentsFromClass[i].Students();
            Console.WriteLine("Enter the following information in the correct order for student " + (i + 1) + " of " + number);
            
            Console.WriteLine("Name: ");
            string name = Convert.ToString(Console.ReadLine());
            studentsFromClass[i].Name = name;
            
            Console.WriteLine("Major: ");
            string major = Console.ReadLine();
            studentsFromClass[i].Major = major;

            Console.WriteLine("Start Date: (YYYY MM DD)");
            DateTime startDate = Convert.ToDateTime(Console.ReadLine());
            studentsFromClass[i].Startdate = startDate;

            Console.WriteLine("Anticipated Graduation Date: ");
            DateTime gradDate = Convert.ToDateTime(Console.ReadLine());
            studentsFromClass[i].AGD = gradDate;

            Console.WriteLine("Mailing Address: ");
            string address = Console.ReadLine();
            studentsFromClass[i].MA = address;

            Console.WriteLine("State: ");
            string state = Console.ReadLine();
            studentsFromClass[i].State = state;
            
            Console.WriteLine("Country: ");
            string country = Console.ReadLine();
            studentsFromClass[i].Country = country;
            
            Console.WriteLine("Email: ");
            string email = Console.ReadLine();
            studentsFromClass[i].Email = email;
            
            Console.WriteLine("Phone: ");
            string phone = Console.ReadLine();
            studentsFromClass[i].Phone = phone;

            //studentsFromClass[i].Student(name,major,startDate,gradDate,state,country,email,phone,address);
            /*
             public int numberOfStudents = 0;
            private int count = 0;
            public int id = 0;
            public string name = "Benjamin Batie";
            public string major = "Computer Information Systems";
            public DateTime startDate = new DateTime(2020, 8, 20);
            public DateTime anticipatedGraduationDate = new DateTime(2023, 12, 9);
            public string state = "South Dakota";
            public string country = "United States of America";
            public string email = "Ben.Batie@trojans.dsu.edu";
            public string phone = "1 (605) 281-9170";
            public string mailingAddress = "402 10th Street / PO Box 522";
             */
        }

        for (int i = 0; i < number; i++) {
            studentsFromClass[i].printStudents();
        }
        Console.WriteLine("Program will end after a key is pressed:");
        Console.ReadLine();
        return;
    }
}






















/*
public partial void addStudents(string NAME, string MAJOR, DateTime START, DateTime END, string STATE, string COUNTRY, string EMAIL, string PHONE, string MAILADDRESS);
}*/
//class Students {
/*
    public int numberOfStudents = 0;
    private int count = 0;
    public int id = 0;
    public string name = "Benjamin Batie";
    public string major = "Computer Information Systems";
    public DateTime startDate = new DateTime(2020, 8, 20);
    public DateTime anticipatedGraduationDate = new DateTime(2023, 12, 9);
    public string state = "South Dakota";
    public string country = "United States of America";
    public string email = "Ben.Batie@trojans.dsu.edu";
    public string phone = "1 (605) 281-9170";
    public string mailingAddress = "402 10th Street / PO Box 522";
*/


/*
    public Students addStudents(string NAME, string MAJOR, DateTime START, DateTime END, string STATE, string COUNTRY, string EMAIL, string PHONE, string MAILADDRESS)
    {
        numberOfStudents++;
        count++;
        id = count;
        name = NAME; 
        major = MAJOR; 
        startDate = START;
        anticipatedGraduationDate = END;
        state = STATE;
        country = COUNTRY;
        email = EMAIL;
        phone = PHONE;
        mailingAddress = MAILADDRESS;
    }*/

    
        /*static void Main(string[] args)
        {

            Students studentsFromClass = new Students();
            Console.WriteLine(studentsFromClass.id);
            Console.WriteLine(studentsFromClass.name);
            Console.WriteLine(studentsFromClass.startDate);
            Console.WriteLine(studentsFromClass.anticipatedGraduationDate);
            Console.WriteLine(studentsFromClass.mailingAddress + " " +studentsFromClass.state + ", " + studentsFromClass.country);
            Console.WriteLine(studentsFromClass.email);
            Console.WriteLine(studentsFromClass.phone);

        }*/
    //}






//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
/*
namespace Shapes {
    public class  Rectangle// : shapestudentsFromClassVersion
    {
        //constructors
        public Rectangle() {
            _height = DefaultHeight;
            _width = DefaultWidth;
        }
        public Rectangle(double height, double width) {
            _height = height;
            _width = width;
        }

        //destructor
        ~Rectangle() { 
        
        }

        //feilds
        private double _height;
        private double _width;
        private const double DefaultHeight = 0;
        private const double DefaultWidth = 0;
    }

}
*/
/*
namespace shapestudentsFromClassVersion
{
    internal class Program
    {
        
    }
}*/

